﻿//////////////////////////////////////////////////
//      MMJ-Finite Automata Tool                //
//      Automaton Class                         //  
//                                              //
//      This class handles data storage for the //
//        automata being simulated.             //
//////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomataGUI
{
    class Automaton
    {
        private List<string> alphabet;
        private List<string> states;
        private string initialState;
        private List<string> acceptingStates;
        private List<Transition> trans;

        // Debugging Func
        public string toString()
        {
            string returnMe = "DEBUG PRINT OF CURRENT AUTOMATA";

            returnMe += "\nAlphabet: ";
            foreach (string s in alphabet)
            {
                returnMe += s;
            }
            returnMe += "\nStates: ";
            foreach (string s in states)
            {
                returnMe += s;
            }
            returnMe += "\nInitial State: ";
            returnMe += initialState;
            returnMe += "\nAccepting States: ";
            foreach (string s in acceptingStates)
            {
                returnMe += s;
            }
            returnMe += "\nTransitions: ";
            foreach (Transition t in trans)
            {
                returnMe += "(" + t.getStart() + "," + t.getData() + "," + t.getEnd() + ") ";
            }

            return returnMe;
        }

        // Getters
        public List<string> getAlphabet()
        {
            return alphabet;
        }
        public List<string> getStates()
        {
            return states;
        }
        public string getInitState()
        {
            return initialState;
        }
        public List<string> getAcceptStates()
        {
            return acceptingStates;
        }
        public List<Transition> getTrans()
        {
            return trans;
        }

        // Setters
        public void setAlphabet(List<string> x)
        {
            alphabet = x.GetRange(0,x.Count);
        }
        public void setStates(List<string> x)
        {
            states = x.GetRange(0, x.Count);
        }
        public void setInitState(string x)
        {
            initialState = x;
        }
        public void setAcceptingStates(List<string> x)
        {
            acceptingStates = x.GetRange(0, x.Count);
        }
        public void setTrans(List<Transition> x)
        {
            trans = x.GetRange(0, x.Count);
        }
    }
}