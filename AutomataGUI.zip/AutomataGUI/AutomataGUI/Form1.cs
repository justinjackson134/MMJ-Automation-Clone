﻿//////////////////////////////////////////////////
//      MMJ-Finite Automata Tool                //
//      Form Class                              //  
//                                              //
//      This class handles all processing and   //
//          UI interactions.                    //
//////////////////////////////////////////////////

// From Winform
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// From Parser
using System.Xml.Linq;
using System.Xml;
using System.IO;

// GUI Events
namespace AutomataGUI
{
    public partial class Form1 : Form
    {
        // Current Automata Var
        private Automaton currentAutomata = new Automaton();

        // Testing Vars
        private bool isTesting = false;
        private bool allPass = true;
        List<string> failedTests = new List<string>();

        // Transition Struct
        struct TransitionPath
        {
            public Transition transition;
            public bool hasVistitedTransition;

            // transitionpath definition
            public TransitionPath(bool visited)
            {
                transition = new Transition();
                hasVistitedTransition = visited;
            }

            public TransitionPath(Transition trans, bool visited)
            {
                transition = trans;
                hasVistitedTransition = visited;
            }

            public bool getHasVisited()
            {
                return hasVistitedTransition;
            }
            public void setHasVisited(bool boo)
            {
                hasVistitedTransition = boo;
            }
        }

        // Used Form Events
        public Form1()
        {
            InitializeComponent();
        }
        private void createNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(textBox6.Text != "" || textBox8.Text != "" || textBox10.Text != "" || textBox12.Text != "" || textBox14.Text != "")
            {
                // If there is text, prompt to save
                var confirmDataErasure = MessageBox.Show("The forms still contain content. Are you sure you wish to empty all forms?", "Confirm Deletion of All Data in Forms", MessageBoxButtons.YesNo);
                if (confirmDataErasure == DialogResult.Yes)
                {
                    textBox6.Text = "";
                    textBox8.Text = "";
                    textBox10.Text = "";
                    textBox12.Text = "";
                    textBox14.Text = "";
                    richTextBox1.Text = "";
                }
            }
            else
            {
                textBox6.Text = "";
                textBox8.Text = "";
                textBox10.Text = "";
                textBox12.Text = "";
                textBox14.Text = "";
                richTextBox1.Text = "";
            }

        }
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //storage for creating
            string save_file_name = "";
            string start_thing = "";
            string input_alphabet = "";
            string state_set = "";
            string initial_state = "";
            string accepting_states = "";
            string transition_set = "";

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //prompt user for automota information
                //Console.WriteLine("Enter filename to save: ");
                save_file_name = saveFileDialog1.FileName;

                //Console.WriteLine("Enter Input alphabet: ");
                input_alphabet = textBox6.Text;
                //Console.WriteLine("Enter States: ");
                state_set = textBox8.Text;
                //Console.WriteLine("Enter Initial State: ");
                initial_state = textBox10.Text;
                //Console.WriteLine("Enter Accepting States: ");
                accepting_states = textBox12.Text;
                //Console.WriteLine("Enter Transition Set: ");
                transition_set = textBox14.Text;

                // Create a root node
                XElement automotas = new XElement("Automata");

                // Add child nodes
                XAttribute start = new XAttribute("Automata_", start_thing); //here

                XElement in_alphabet = new XElement("inputAlphabet", input_alphabet);
                XElement s_set = new XElement("stateSet", state_set);
                XElement in_state = new XElement("intialState", initial_state);
                XElement acc_states = new XElement("acceptingStates", accepting_states);
                XElement trans_set = new XElement("transitionSet", transition_set);
                XElement automota = new XElement("automata");
                automota.Add(start);
                automota.Add(in_alphabet);
                automota.Add(s_set);
                automota.Add(in_state);
                automota.Add(acc_states);
                automota.Add(trans_set);
                automotas.Add(automota);

                //Save file
                automotas.Save(save_file_name);
            }
        }
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string load_file_name = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((openFileDialog1.OpenFile()) != null)
                    {
                        load_file_name = openFileDialog1.FileName;

                        richTextBox1.Text = File.ReadAllText(load_file_name);

                        //loop for displaying 
                        XElement allData = XElement.Load(load_file_name);
                        if (allData != null)
                        {
                            int i = 1;

                            IEnumerable<XElement> elements = allData.Elements().Descendants(); //here
                            foreach (XElement element in elements)
                            {
                                switch (i)
                                {
                                    case 1:
                                        textBox6.Text = (string)element;
                                        i++;
                                        break;
                                    case 2:
                                        textBox8.Text = (string)element;
                                        i++;
                                        break;
                                    case 3:
                                        textBox10.Text = (string)element;
                                        i++;
                                        break;
                                    case 4:
                                        textBox12.Text = (string)element;
                                        i++;
                                        break;
                                    case 5:
                                        textBox14.Text = (string)element;
                                        i++;
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void parseTextBoxes()
        {
            //storage for parsing
            string[] split;
            List<string> toPass = new List<string>();
            string input_alphabet = "";
            string state_set = "";
            string initial_state = "";
            string accepting_states = "";
            List<Transition> transList = new List<Transition>();
            string transition_set = "";

            
            // Get text box stirng values to parse
            input_alphabet = textBox6.Text;
            state_set = textBox8.Text;
            initial_state = textBox10.Text;
            accepting_states = textBox12.Text;
            transition_set = textBox14.Text;

            // parse Alphabet
            toPass.Clear();
            split = input_alphabet.Split(',');
            foreach (string s in split)
            {
                toPass.Add(s);
            }
            currentAutomata.setAlphabet(toPass);

            // parse States
            toPass.Clear();
            split = state_set.Split(',');
            foreach (string s in split)
            {
                toPass.Add(s);
            }
            currentAutomata.setStates(toPass);

            // parse Initial State
            currentAutomata.setInitState(initial_state);

            // parse Accepting States
            toPass.Clear();
            split = accepting_states.Split(',');
            foreach (string s in split)
            {
                toPass.Add(s);
            }
            currentAutomata.setAcceptingStates(toPass);

            // parse Transition Set
            toPass.Clear();
            transition_set = transition_set.Replace(")","");
            split = transition_set.Split('(');
            foreach (string s in split)
            {
                if (s != "") // Stop the program from grabbing an empty transition set
                {
                    toPass.Add(s);
                }
            }

            foreach (string s in toPass)
            {
                split = s.Split(',');

                int i = 0;
                Transition transition = new Transition();
                foreach (string ss in split)
                {
                    switch (i)
                    {
                        case 0:
                            transition.setStart(ss);
                            break;
                        case 1:
                            transition.setData(ss);
                            break;
                        case 2:
                            transition.setEnd(ss);
                            break;
                    }
                    i++;
                }

                transList.Add(transition);
            }
            currentAutomata.setTrans(transList);
            
            System.Console.WriteLine(currentAutomata.toString());
        }

        //Checks if State set is valid. Returns true if valid, false if not valid
        private bool checkStates(Automaton a)
        {
            //if there are no states, automaton is not valid
            if (a.getStates().Count == 0)
            {
                if(!isTesting) MessageBox.Show("The state set must contain at least one state", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            //if there are any states that are named empty strings, automaton is not valid
            foreach (string state in a.getStates())
                if (state == "")
                {
                    if (!isTesting) MessageBox.Show("The state set can not contain an unnamed state", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            return true;
        }

        //returns true if Inital state is not an empty string is in the state set
        private bool checkInitial(Automaton a)
        {
            //if InitState is empty string, automaton is not valid
            if (a.getInitState() == "")
            {
                if (!isTesting) MessageBox.Show("The initial state cannot be unnamed", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            //if InitState is not in States, automaton is not valid
            if (a.getInitState().Contains(a.getInitState()) == false)
            {
                if (!isTesting) MessageBox.Show("The initial state must be in the state set", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        //Returns true is there are accepting states and the accepting states are in the state set
        private bool checkAccepting(Automaton a)
        {
            //If there are accepting states, proceed
            if (a.getAcceptStates().Count > 0)
            {
                //check if each accepting state is in the state set
                foreach (string AcceptingState in a.getAcceptStates())
                {
                    if (a.getStates().Contains(AcceptingState) == false)
                    {
                        if (!isTesting) MessageBox.Show("The accepting state must be an element of the state set", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            else
            {
                if (!isTesting) MessageBox.Show("There must be at least one accepting state", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        // Called from check transitions
        private bool checkValidPath(TransitionPath[] transitions, List<string> acceptingStates, Transition currentTransition)
        {
            bool isValid = false;
            if (acceptingStates.Contains(currentTransition.getEnd()))
            {
                isValid = true;
            }
            else
            {
                int transIndex = -1;
                for (int i = 0; i < transitions.Count(); i++)
                {
                    if (transitions[i].transition.Equals(currentTransition))
                    {
                        if (transitions[i].getHasVisited() == false)
                        {
                            transIndex = i;
                            transitions[i].setHasVisited(true);
                        }
                        break;
                    }
                }
                if (transIndex != -1)
                {
                    // go through each transition check if it is a valid path...
                    foreach (TransitionPath transPath in transitions)
                    {
                        if (transPath.transition.getStart() == currentTransition.getEnd())
                        {
                            isValid = checkValidPath(transitions, acceptingStates, transPath.transition);
                            if (isValid == true)
                                break;
                        }
                    }
                }
            }
            return isValid;
        }

        //returns true if transitions are valid (start/end and data are included in the state set and alphabet)
        private bool checkTransitions(Automaton a)
        {
            //if there are transitions, proceed
            if (a.getTrans().Count > 0)
            {
                foreach (Transition trans in a.getTrans())
                {
                    //is the start state in State set?
                    if (a.getStates().Contains(trans.getStart()) == false)
                    {
                        if (!isTesting) MessageBox.Show("The start state of the transition must be in the state set", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    //is the data contained in alphabet?    
                    if (a.getAlphabet().Contains(trans.getData()) == false)
                    {
                        if (!isTesting) MessageBox.Show("The transition value must be in the alphabet", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                    //is the end state contained in State set?        
                    if (a.getStates().Contains(trans.getEnd()) == false)
                    {
                        if (!isTesting) MessageBox.Show("The end state of the transition must be in the state set", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }

                TransitionPath[] transitions = new TransitionPath[a.getTrans().Count];
                for (int i = 0; i < transitions.Count(); i++)
                {
                    transitions[i].transition = a.getTrans()[i];
                    transitions[i].setHasVisited(false);
                }

                List<Transition> initialTransitions = new List<Transition>();

                foreach (Transition transition in a.getTrans())
                {
                    if (transition.getStart() == a.getInitState())
                        initialTransitions.Add(transition);
                }

                bool foundValid = false;

                foreach (Transition transition in initialTransitions)
                {
                    if (checkValidPath(transitions, a.getAcceptStates(), transition))
                    {
                        foundValid = true;
                        break;
                    }
                }

                if (foundValid == false)
                {
                    if (!isTesting) MessageBox.Show("There are no valid paths from the start state to an accepting state", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            else
            {
                if (!isTesting) MessageBox.Show("The transition set cannot be empty", "Invalid Automata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void validateCurrentAutomata()
        {
            // Make sure automata is valid, throw error otherwise (popup window)
            if (checkStates(currentAutomata) && checkInitial(currentAutomata) && checkAccepting(currentAutomata) && checkTransitions(currentAutomata))
                System.Console.WriteLine("AUTOMATA IS VALID");
            else
                System.Console.WriteLine("AUTOMATA IS INVALID");
        }

        private void updateXMLDisplay()
        {
            string start_thing = "";
            string input_alphabet = "";
            string state_set = "";
            string initial_state = "";
            string accepting_states = "";
            string transition_set = "";

            //Console.WriteLine("Enter Input alphabet: ");
            input_alphabet = textBox6.Text;
            //Console.WriteLine("Enter States: ");
            state_set = textBox8.Text;
            //Console.WriteLine("Enter Initial State: ");
            initial_state = textBox10.Text;
            //Console.WriteLine("Enter Accepting States: ");
            accepting_states = textBox12.Text;
            //Console.WriteLine("Enter Transition Set: ");
            transition_set = textBox14.Text;

            // Create a root node
            XElement automotas = new XElement("Automata");

            // Add child nodes
            XAttribute start = new XAttribute("Automata_", start_thing); //here

            XElement in_alphabet = new XElement("inputAlphabet", input_alphabet);
            XElement s_set = new XElement("stateSet", state_set);
            XElement in_state = new XElement("intialState", initial_state);
            XElement acc_states = new XElement("acceptingStates", accepting_states);
            XElement trans_set = new XElement("transitionSet", transition_set);
            XElement automota = new XElement("automata");
            automota.Add(start);
            automota.Add(in_alphabet);
            automota.Add(s_set);
            automota.Add(in_state);
            automota.Add(acc_states);
            automota.Add(trans_set);
            automotas.Add(automota);

            richTextBox1.Text = ("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" + automotas.ToString());
        }

        // Called from Update finite automata and Test Word
        private void UpdateCurrentFA()
        {
            parseTextBoxes();
            updateXMLDisplay();
            validateCurrentAutomata();
        }

        // Update Finite Automata
        private void UpdateFiniteAutomata_Click(object sender, EventArgs e)
        {
            UpdateCurrentFA();
        }

        // Update the checkboxes above test word
        private void updateValidInvalidCheckboxes(int val)
        {
            if (val == 0)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
            }
            else if (val == 1)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
            }
            else if (val == 2)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = true;
            }
        }

        // Test Word
        private void button1_Click(object sender, EventArgs e)
        {
            // Update current automata to make sure we test against what we see
            UpdateCurrentFA();
            
            if (testWord(textBox1.Text, currentAutomata))
            {
                updateValidInvalidCheckboxes(1);
            }
            else
            {
                updateValidInvalidCheckboxes(2);
            }
        }

        private bool testWord(string input, Automaton a)
        {
            bool good = false;
            bool foundTransition = false;
            string currentState = a.getInitState();

            foreach (char symbol in input)
            {
                if (!a.getAlphabet().Contains(symbol.ToString()))
                {
                    MessageBox.Show("The word cannot contain items that are not in the alphabet", "Invalid Word", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }

            // read input string
            while (input != "")
            {
                string currentInput = "";

                // Input symbol
                foreach (string symbol in a.getAlphabet())
                {
                    int symbolLength = symbol.Length; // get length of the current input symbol
                    try
                    {
                        // get the next input symbol
                        string temp = input.Substring(0, symbolLength);
                        // if the symbols are the same, we have the current input symbol
                        if (symbol == temp)
                        {
                            currentInput = symbol;

                            break;
                        }
                    }
                    catch { }

                }

                if (currentInput == "")
                {
                    break;
                }

                // remove the current input symbol from the input string
                input = input.Remove(0, currentInput.Length);


                foundTransition = false;

                //Transition
                foreach (Transition transition in a.getTrans())
                {
                    //does the current state match the transition state?
                    if (transition.getStart() == currentState)
                    {
                        // does the current data match the transition data?
                        if (transition.getData() == currentInput)
                        {
                            // found transition
                            currentState = transition.getEnd();
                            foundTransition = true;
                            break;
                        }
                    }
                }

                if (foundTransition == false)
                    break;
            }

            //Final
            if (foundTransition == true)
            {
                //determine if the current state matches a valid final state
                foreach (string state in a.getAcceptStates())
                {
                    // if current state matches the selected final state then the string is valid
                    if (currentState == state)
                    {
                        good = true;
                        break;
                    }
                }
            }
            return good;
        }

        // If test word text changed, reset checkboxes
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            updateValidInvalidCheckboxes(0);
        }

        private void runAllTestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            failedTests.Clear();
            isTesting = true;
            allPass = true;

            if (!testNoPathToGoal()) allPass = false;
            if (!testCircularPath()) allPass = false;
            if (!WordSuccessfulTest()) allPass = false;
            if (!WordFailedTest()) allPass = false;
            if (!testInvalidAlphabet()) allPass = false;


            

            if (allPass)
            {
                MessageBox.Show("All (5) Tests Passed");
            }
            else
            {
                string msg = "Some Tests Failed;\n";

                for(int i = 0; i < failedTests.Count(); i++)
                {
                    msg = msg + failedTests[i] + "\n";
                }

                MessageBox.Show(msg, "Test Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            isTesting = false;
        }

        private void testLoadBoxes(string alphabet, string states, string initial, string acceptings, string trans, string word)
        {
            textBox6.Text = alphabet;
            textBox8.Text = states;
            textBox10.Text = initial;
            textBox12.Text = acceptings;
            textBox14.Text = trans;

            textBox1.Text = word;

            UpdateCurrentFA();

            if (testWord(textBox1.Text, currentAutomata))
            {
                updateValidInvalidCheckboxes(1);
            }
            else
            {
                updateValidInvalidCheckboxes(2);
            }
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isTesting = true;

            if (testNoPathToGoal())
                MessageBox.Show("No Path to Goal Test: Passed", "Test Passed", MessageBoxButtons.OK, MessageBoxIcon.None);
            else
                MessageBox.Show("No Path to Goal Test: Failed", "Test Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        
            isTesting = false;
        }
        private void circularPathToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isTesting = true;

            if (testCircularPath())
                MessageBox.Show("Circular Path Test: Passed", "Test Passed", MessageBoxButtons.OK, MessageBoxIcon.None);
            else
                MessageBox.Show("Circular Path Test: Failed", "Test Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            isTesting = false;
        }
        private void standardSucessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isTesting = true;

            if (WordSuccessfulTest())
                MessageBox.Show("Word Should Pass Test: Passed", "Test Passed", MessageBoxButtons.OK, MessageBoxIcon.None);
            else
                MessageBox.Show("Word Should Pass Test: Failed", "Test Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            isTesting = false;
        }
        private void standardFailureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isTesting = true;

            if (WordFailedTest())
                MessageBox.Show("Word Should Fail Test: Passed", "Test Passed", MessageBoxButtons.OK, MessageBoxIcon.None);
            else
                MessageBox.Show("Word Should Fail Test: Failed", "Test Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            isTesting = false;
        }
        private void invalidAlphabetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isTesting = true;

            if (testInvalidAlphabet())
                MessageBox.Show("Invalid Alphabet Test: Passed", "Test Passed", MessageBoxButtons.OK, MessageBoxIcon.None);
            else
                MessageBox.Show("Invalid Alphabet Test: Failed", "Test Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            isTesting = false;
        }

        // Test Cases
        private bool testNoPathToGoal()
        {
            // Replace these vars with the strings that correspond.
            testLoadBoxes("1,0", "a,b,c,d", "a", "d", "(a,1,b),(a,0,c),(c,1,d)", "10");
            // Replace wordToTest with the word we should test. Replace expectedResult with true/false.
            if (testWord("10", currentAutomata) != false)
            {
                // We Fail
                failedTests.Add("No Path to Goal");
                return false;
            }
            // We Pass
            return true;
        }
        private bool testCircularPath()
        {
            // Replace these vars with the strings that correspond.
            testLoadBoxes("0,1", "a,b,c", "a", "a", "(a,0,b),(b,0,c),(c,1,a),(c,1,b)", "001");
            // Replace wordToTest with the word we should test. Replace expectedResult with true/false.
            if (testWord("001", currentAutomata) != true)
            {
                // We Fail
                failedTests.Add("Circular Path");
                return false;
            }
            // We Pass
            return true;
        }
        private bool testInvalidAlphabet()
        {
            // Replace these vars with the strings that correspond.
            testLoadBoxes("0,1", "a,b,c,d", "a", "c", "(a,0,b),(b,2,c),(b,1,d)", "01");
            // Replace wordToTest with the word we should test. Replace expectedResult with true/false.
            if (testWord("01", currentAutomata) != false)
            {
                // We Fail
                failedTests.Add("Invalid Alphabet");
                return false;
            }
            // We Pass
            return true;
        }
        private bool WordSuccessfulTest()
        {
            // Replace these vars with the strings that correspond.
            testLoadBoxes("0,1", "a,b,c", "a", "b", "(a,0,b),(b,1,c),(c,1,b)", "01111");
        
          // Replace wordToTest with the word we should test. Replace expectedResult with true/false.
            if (testWord("01111", currentAutomata) != true)
            {
                // We should fail
                failedTests.Add("Standard Word Should Pass Test");
                return false;
            }
            // We Pass
            return true;
        }
        private bool WordFailedTest()
        {
            // Replace these vars with the strings that correspond.
            testLoadBoxes("0,1", "a,b,c", "a", "b", "(a,0,b),(b,1,c),(c,1,b)", "0111");
        
          // Replace wordToTest with the word we should test. Replace expectedResult with true/false.
            if (testWord("0111", currentAutomata) != false)
            {
                // We don't fail
                failedTests.Add("Standard Word Should Fail Test");
                return false;
            }
            // We Pass
            return true;
        }
        
        // Unused Generated Events - Cannot be deleted
        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void label6_Click_1(object sender, EventArgs e)
        {

        }
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void label8_Click(object sender, EventArgs e)
        {

        }

        
    }
}
