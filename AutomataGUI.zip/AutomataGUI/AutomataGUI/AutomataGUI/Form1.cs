﻿// From Winform
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// From Parser
using System.Xml.Linq;
using System.Xml;

// GUI Events
namespace AutomataGUI
{
    public partial class Form1 : Form
    {
        // Used Form Events
        public Form1()
        {
            InitializeComponent();
        }

        private void createNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(textBox6.Text != "" || textBox8.Text != "" || textBox10.Text != "" || textBox12.Text != "" || textBox14.Text != "")
            {
                // If there is text, prompt to save
                var confirmDataErasure = MessageBox.Show("The forms still contain content. Are you sure you wish to empty all forms?", "Confirm Deletion of All Data in Forms", MessageBoxButtons.YesNo);
                if (confirmDataErasure == DialogResult.Yes)
                {
                    textBox6.Text = "";
                    textBox8.Text = "";
                    textBox10.Text = "";
                    textBox12.Text = "";
                    textBox14.Text = "";
                }
            }
            else
            {
                textBox6.Text = "";
                textBox8.Text = "";
                textBox10.Text = "";
                textBox12.Text = "";
                textBox14.Text = "";
            }

        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //storage for creating
            string save_file_name = "";
            string start_thing = "";
            string input_alphabet = "";
            string state_set = "";
            string initial_state = "";
            string accepting_states = "";
            string transition_set = "";

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //prompt user for automota information
                //Console.WriteLine("Enter filename to save: ");
                save_file_name = saveFileDialog1.FileName;

                //Console.WriteLine("Enter Input alphabet: ");
                input_alphabet = textBox6.Text;
                //Console.WriteLine("Enter States: ");
                state_set = textBox8.Text;
                //Console.WriteLine("Enter Initial State: ");
                initial_state = textBox10.Text;
                //Console.WriteLine("Enter Accepting States: ");
                accepting_states = textBox12.Text;
                //Console.WriteLine("Enter Transition Set: ");
                transition_set = textBox14.Text;

                // Create a root node
                XElement automotas = new XElement("Automata");

                // Add child nodes
                XAttribute start = new XAttribute("Automata_", start_thing); //here

                XElement in_alphabet = new XElement("inputAlphabet", input_alphabet);
                XElement s_set = new XElement("stateSet", state_set);
                XElement in_state = new XElement("intialState", initial_state);
                XElement acc_states = new XElement("acceptingStates", accepting_states);
                XElement trans_set = new XElement("transitionSet", transition_set);
                XElement automota = new XElement("automata");
                automota.Add(start);
                automota.Add(in_alphabet);
                automota.Add(s_set);
                automota.Add(in_state);
                automota.Add(acc_states);
                automota.Add(trans_set);
                automotas.Add(automota);

                //Save file
                automotas.Save(save_file_name);
            }
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string load_file_name = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((openFileDialog1.OpenFile()) != null)
                    {
                        load_file_name = openFileDialog1.FileName;

                        //loop for displaying 
                        XElement allData = XElement.Load(load_file_name);
                        if (allData != null)
                        {
                            int i = 1;

                            IEnumerable<XElement> elements = allData.Elements().Descendants(); //here
                            foreach (XElement element in elements)
                            {
                                switch (i)
                                {
                                    case 1:
                                        textBox6.Text = (string)element;
                                        i++;
                                        break;
                                    case 2:
                                        textBox8.Text = (string)element;
                                        i++;
                                        break;
                                    case 3:
                                        textBox10.Text = (string)element;
                                        i++;
                                        break;
                                    case 4:
                                        textBox12.Text = (string)element;
                                        i++;
                                        break;
                                    case 5:
                                        textBox14.Text = (string)element;
                                        i++;
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Unused Generated Events
        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
