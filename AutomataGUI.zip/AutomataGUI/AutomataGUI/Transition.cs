﻿//////////////////////////////////////////////////
//      MMJ-Finite Automata Tool                //
//      Transitions Class                       //  
//                                              //
//      This class handles data storage for the //
//        transition elements of the automata   //
//////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomataGUI
{
    class Transition
    {
        private string Start;
        private string End;
        private string Data;

        // Getters
        public string getStart()
        {
            return Start;
        }
        public string getEnd()
        {
            return End;
        }
        public string getData()
        {
            return Data;
        }

        // Setters
        public void setStart(string x)
        {
            Start = x;
        }
        public void setEnd(string x)
        {
            End = x;
        }
        public void setData(string x)
        {
            Data = x;
        }
    }
}
