﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutomataGUI
{
    public partial class SaveWorkPrompt : Form
    {
        public SaveWorkPrompt()
        {
            InitializeComponent();
        }

        private void SaveWorkPrompt_Load(object sender, EventArgs e)
        {

        }
    }
}
